﻿param([switch]$Silent = $false)
$InstallPath = $PSScriptRoot
if (-not $Silent) { Write-Host "Uninstalling Mist Native Game Streaming Platform v0.3.0-rc3..." -ForegroundColor Cyan }
$startMenuDir = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Mist"
if (Test-Path $startMenuDir) { Remove-Item -Path $startMenuDir -Recurse -Force -ErrorAction SilentlyContinue }
$regKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Mist"
if (Test-Path $regKey) { Remove-Item -Path $regKey -Force -ErrorAction SilentlyContinue }
if (Test-Path $InstallPath) {
    $files = Get-ChildItem -Path $InstallPath -Recurse | Where-Object { $_.FullName -ne "$PSScriptRoot\uninstall.ps1" }
    foreach ($f in $files) { Remove-Item -Path $f.FullName -Force -Recurse -ErrorAction SilentlyContinue }
}
if (-not $Silent) { Write-Host "Mist v0.3.0-rc3 uninstallation complete." -ForegroundColor Green }
