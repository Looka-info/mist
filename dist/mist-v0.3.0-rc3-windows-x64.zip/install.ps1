﻿param(
    [string]$InstallPath = "$env:LOCALAPPDATA\Programs\Mist",
    [switch]$Silent = $false
)
$ErrorActionPreference = "Stop"
if (-not $Silent) { Write-Host "Installing Mist Native Game Streaming Platform v0.3.0-rc3..." -ForegroundColor Cyan }
if (-not (Test-Path $InstallPath)) { New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null }
$scriptRoot = $PSScriptRoot
Copy-Item -Path "$scriptRoot\bin\*" -Destination $InstallPath -Recurse -Force
Copy-Item -Path "$scriptRoot\config" -Destination $InstallPath -Recurse -Force
Copy-Item -Path "$scriptRoot\uninstall.ps1" -Destination "$InstallPath\uninstall.ps1" -Force
$startMenuDir = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Mist"
if (-not (Test-Path $startMenuDir)) { New-Item -ItemType Directory -Path $startMenuDir -Force | Out-Null }
try {
    $wsh = New-Object -ComObject WScript.Shell
    $shortcut = $wsh.CreateShortcut("$startMenuDir\Mist Desktop.lnk")
    $shortcut.TargetPath = "$InstallPath\mist_desktop.exe"
    $shortcut.WorkingDirectory = $InstallPath
    $shortcut.Description = "Mist Native Game Streaming Desktop Application"
    $shortcut.Save()
} catch {}
$regKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Mist"
if (-not (Test-Path $regKey)) { New-Item -Path $regKey -Force | Out-Null }
Set-ItemProperty -Path $regKey -Name "DisplayName" -Value "Mist Native Game Streaming Platform"
Set-ItemProperty -Path $regKey -Name "DisplayVersion" -Value "0.3.0-rc3"
Set-ItemProperty -Path $regKey -Name "Publisher" -Value "Mist Systems Architecture"
Set-ItemProperty -Path $regKey -Name "InstallLocation" -Value $InstallPath
Set-ItemProperty -Path $regKey -Name "UninstallString" -Value "powershell.exe -ExecutionPolicy Bypass -File `"$InstallPath\uninstall.ps1`""
if (-not $Silent) { Write-Host "Mist v0.3.0-rc3 successfully installed to: $InstallPath" -ForegroundColor Green }
